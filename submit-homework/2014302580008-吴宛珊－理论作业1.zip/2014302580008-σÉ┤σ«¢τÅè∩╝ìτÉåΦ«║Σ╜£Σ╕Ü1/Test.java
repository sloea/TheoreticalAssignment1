package a;



import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.text.ParseException;
import java.util.LinkedList;
import java.util.List;

public class Test {

	/**
	 * @param args
	 * @throws ParseException 
	 * @throws IOException 
	 */
	public static void main(String[] args) throws ParseException, IOException {		
		InputStreamReader reader = new InputStreamReader(new FileInputStream("/Users/Oscar/scorce.txt"),"utf-16");   //保存原始数据的txt文档
		String a ="";
		int b;
		while((b=reader.read())!=-1){  			               
			                   char c = (char) b;  
			                    a+=String.valueOf(c);  
			           }
		System.out.println(a);
		String[] strs = a.replaceAll("\r", "").split("\n");
		System.out.println(strs);
		List<String> list = new LinkedList<String>();
		List<String> sortList = new LinkedList<String>();
		for(int i=1;i<strs.length;i++){
			list.add(strs[i]);
		}
		//System.out.println(list);
		for(int k=0;k<list.size();k++){
			String s1 = list.get(k).replaceAll("\r", "");
			String[] personInfo1 = s1.split("\t");//切简单数据可以,复杂数据有问题
			
			for(int j=list.size()-1;j>=0;j--){
				int yw1 = Integer.valueOf(personInfo1[3]);
				
				
				String s2 = list.get(j);
				String[] personInfo2 = s2.split("\t");
				int yw2 = Integer.valueOf(personInfo2[3]);
				
				if(yw1<yw2){
					break;
				}else{
					if(j==0){
						sortList.add(s1);
						list.remove(s1);
						k=-1;
					}
				}
			}
		}
		System.out.println(list.size());
		System.out.println(sortList.size());
		
		a = strs[0];
		for(String str:sortList){
			a += "\n" + str;
		}
		
		File f = new File("/Users/Oscar/sort_test.txt");
		OutputStreamWriter writer = new OutputStreamWriter(new FileOutputStream(f));
		writer.write(a, 0, a.length());
		writer.close();
	}

}